# Grade 5 Mathematics Learning App

A mobile-first, offline-capable Grade 5 Mathematics PWA prototype.

## Features

- Grade 5 Mathematics units and topics
- Interactive lessons and worked examples
- Practice questions with automatic marking
- Mixed mathematics quiz
- Student progress and points
- Badges
- Teacher overview
- English/Amharic interface
- Local persistence using browser localStorage
- Service-worker caching for offline use

## Run locally

Because service workers generally require HTTP(S), run a small local server.

### Python

```bash
python -m http.server 8000
```

Then open:

http://localhost:8000

## Deploy

The files can be deployed to any static hosting service that supports HTTPS.

## Important

This is an MVP/prototype. It intentionally uses local browser storage and demo data. For production use with real students, add a secure backend, authentication, database, role-based access control, consent/privacy controls, backups, server-side reporting, and verified curriculum content.
