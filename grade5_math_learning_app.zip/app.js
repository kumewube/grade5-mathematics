const DATA={
units:[
{id:1,title:"Whole Numbers",am:"ሙሉ ቁጥሮች",icon:"🔢",topics:[
{id:"place",title:"Place Value",lesson:"Place value tells us the value of a digit because of its position. In 45,672, the 4 means 40,000.",example:"45,672 = 40,000 + 5,000 + 600 + 70 + 2",questions:[
["What is the value of 7 in 47,325?",["7","70","700","7,000"],1],
["Which number is greater?",["35,210","35,201","35,120","35,012"],0],
["Write 8,405 in expanded form.",["8,000+400+5","800+40+5","8,000+40+5","8,000+400+50"],0]
]},
{id:"operations",title:"The Four Operations",lesson:"Addition combines quantities. Subtraction finds a difference. Multiplication is repeated addition, while division shares into equal groups.",example:"125 + 236 = 361. 600 − 245 = 355. 24 × 3 = 72. 84 ÷ 7 = 12.",questions:[
["36 × 4 = ?",["120","124","144","164"],2],
["540 ÷ 9 = ?",["50","60","70","90"],1],
["725 − 318 = ?",["397","407","417","437"],1]
]}
]},
{id:2,title:"Fractions",am:"ክፍልፋዮች",icon:"🍕",topics:[
{id:"meaning",title:"Understanding Fractions",lesson:"A fraction describes equal parts of a whole. The numerator counts selected parts and the denominator tells how many equal parts make the whole.",example:"3/4 means 3 of 4 equal parts.",questions:[
["In 5/8, what is the denominator?",["5","8","13","3"],1],
["Which fraction is equal to one half?",["1/3","2/4","3/5","4/6"],1],
["Which is greater?",["1/4","3/4","1/8","2/8"],1]
]},
{id:"add",title:"Adding Fractions",lesson:"When fractions have the same denominator, add the numerators and keep the denominator.",example:"2/7 + 3/7 = 5/7.",questions:[
["2/9 + 4/9 = ?",["6/9","6/18","2/9","4/9"],0],
["1/5 + 2/5 = ?",["2/5","3/5","3/10","1/5"],1],
["3/8 + 1/8 = ?",["3/8","4/8","4/16","2/8"],1]
]}
]},
{id:3,title:"Decimals",am:"ዴሲማሎች",icon:"🔟",topics:[
{id:"decimal-place",title:"Decimal Place Value",lesson:"Digits after the decimal point represent tenths, hundredths and so on.",example:"0.37 = 3 tenths + 7 hundredths.",questions:[
["Which is greater?",["0.5","0.05","0.15","0.25"],0],
["What is the value of 6 in 2.64?",["6","0.6","0.06","60"],1],
["0.4 is equal to:",["4/100","40/100","4/1000","1/4"],1]
]}
]},
{id:4,title:"Geometry",am:"ጂኦሜትሪ",icon:"📐",topics:[
{id:"shapes",title:"2D Shapes",lesson:"A polygon is a closed plane figure made from straight line segments. Triangles have 3 sides and quadrilaterals have 4.",example:"A rectangle is a quadrilateral with four right angles.",questions:[
["How many sides does a pentagon have?",["4","5","6","8"],1],
["A triangle has how many sides?",["2","3","4","5"],1],
["Which shape has four sides?",["Triangle","Circle","Quadrilateral","Pentagon"],2]
]},
{id:"perimeter",title:"Perimeter",lesson:"Perimeter is the total distance around a shape. Add the lengths of all its sides.",example:"A rectangle 6 cm by 4 cm has perimeter 6+4+6+4 = 20 cm.",questions:[
["Perimeter of a square with side 5 cm?",["10 cm","15 cm","20 cm","25 cm"],2],
["A rectangle is 8 m by 3 m. Perimeter?",["11 m","22 m","24 m","30 m"],1]
]}
]},
{id:5,title:"Measurement",am:"መለኪያ",icon:"📏",topics:[
{id:"length",title:"Length",lesson:"Length can be measured using units such as millimetres, centimetres, metres and kilometres.",example:"1 metre = 100 centimetres.",questions:[
["1 metre equals:",["10 cm","50 cm","100 cm","1000 cm"],2],
["Which is most suitable for measuring the distance between towns?",["mm","cm","m","km"],3],
["200 cm equals:",["2 m","20 m","200 m","0.2 m"],0]
]}
]},
{id:6,title:"Data",am:"መረጃ",icon:"📊",topics:[
{id:"graphs",title:"Tables and Bar Graphs",lesson:"A table organizes data. A bar graph represents quantities using bars, making comparisons easier.",example:"If 8 students choose football and 5 choose basketball, football has 3 more votes.",questions:[
["A bar graph is useful for:",["Comparing categories","Measuring temperature only","Writing stories","Drawing circles only"],0],
["If 12 students like apples and 7 like bananas, how many more like apples?",["3","5","7","19"],1]
]}
]}
]};

let state=JSON.parse(localStorage.getItem("g5math")||"null")||{name:"Student",role:"student",completed:{},scores:[],points:0,streak:0,lang:"en"};
let currentTopic=null,currentQ=0,currentScore=0,quizQuestions=[];

function save(){localStorage.setItem("g5math",JSON.stringify(state))}
function t(en,am){return state.lang==="am"?am||en:en}
function app(){document.getElementById("app").innerHTML=`
<header class="topbar"><div class="brand">🧮 ${t("Grade 5 Mathematics","5ኛ ክፍል ሂሳብ")}</div>
<button class="lang" onclick="toggleLang()">${state.lang==="en"?"አማ":"EN"}</button></header>
<div class="shell"><aside class="sidebar">
<button class="navbtn active" onclick="home()">🏠 <span class="label">${t("Home","መነሻ")}</span></button>
<button class="navbtn" onclick="courses()">📚 <span class="label">${t("Courses","ትምህርቶች")}</span></button>
<button class="navbtn" onclick="practice()">✏️ <span class="label">${t("Practice","ልምምድ")}</span></button>
<button class="navbtn" onclick="quiz()">📝 <span class="label">${t("Quiz","ፈተና")}</span></button>
<button class="navbtn" onclick="progress()">📈 <span class="label">${t("Progress","እድገት")}</span></button>
<button class="navbtn" onclick="teacher()">👨‍🏫 <span class="label">${t("Teacher","መምህር")}</span></button>
</aside><main class="main" id="main"></main></div>`;home()}
function toggleLang(){state.lang=state.lang==="en"?"am":"en";save();app()}
function home(){document.getElementById("main").innerHTML=`<section class="hero"><h1>${t("Learn Mathematics with confidence!","በራስ መተማመን ሂሳብን ተማር!")}</h1><p>${t("Learn, practice, take quizzes and track your progress.","ተማር፣ ተለማመድ፣ ፈተና ውሰድ እና እድገትህን ተከታተል።")}</p><div class="actions"><button class="btn" onclick="courses()">${t("Start Learning","መማር ጀምር")}</button><button class="btn secondary" onclick="quiz()">${t("Take a Quiz","ፈተና ውሰድ")}</button></div></section>
<div class="grid"><div class="card"><div class="muted">${t("Points","ነጥቦች")}</div><div class="stat">${state.points}</div></div><div class="card"><div class="muted">${t("Lessons completed","የተጠናቀቁ ትምህርቶች")}</div><div class="stat">${Object.values(state.completed).filter(Boolean).length}</div></div><div class="card"><div class="muted">${t("Badges","ሽልማቶች")}</div><div class="stat">${badges().length}</div></div></div>
<div class="card" style="margin-top:18px"><h3>${t("Recommended next","ቀጣይ የሚመከር")}</h3><p>${t("Continue with a lesson and earn points by completing practice questions.","ትምህርት ቀጥል እና የልምምድ ጥያቄዎችን በመመለስ ነጥቦች ሰብስብ።")}</p></div>`}
function courses(){document.getElementById("main").innerHTML=`<h2>${t("Grade 5 Mathematics Course","የ5ኛ ክፍል የሂሳብ ትምህርት")}</h2><div class="grid">${DATA.units.map(u=>`<div class="card unit"><h3>${u.icon} ${t(u.title,u.am)}</h3><p>${u.topics.length} ${t("topics","ርዕሶች")}</p>${u.topics.map(x=>`<button class="btn secondary" style="margin:4px" onclick="lesson('${x.id}')">${state.completed[x.id]?"✓ ":""}${x.title}</button>`).join("")}</div>`).join("")}</div>`}
function findTopic(id){for(const u of DATA.units){const x=u.topics.find(x=>x.id===id);if(x)return x}}
function lesson(id){currentTopic=findTopic(id);document.getElementById("main").innerHTML=`<div class="lesson"><div class="card"><h2>📖 ${currentTopic.title}</h2><h3>${t("Learning objective","የመማር ዓላማ")}</h3><p>${currentTopic.lesson}</p><div class="example"><strong>${t("Worked example","የተሰራ ምሳሌ")}:</strong><br>${currentTopic.example}</div><button class="btn" onclick="startPractice('${id}')">${t("Start Practice","ልምምድ ጀምር")}</button></div></div>`}
function startPractice(id){currentTopic=findTopic(id);currentQ=0;currentScore=0;practiceQuestion()}
function practiceQuestion(){const q=currentTopic.questions[currentQ];document.getElementById("main").innerHTML=`<div class="lesson"><div class="card"><div class="muted">${currentQ+1} / ${currentTopic.questions.length}</div><div class="progress"><div style="width:${currentQ/currentTopic.questions.length*100}%"></div></div><div class="question">${q[0]}</div><div id="opts">${q[1].map((o,i)=>`<button class="option" onclick="answer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}</div><div id="fb"></div></div></div>`}
function answer(i){const q=currentTopic.questions[currentQ];document.querySelectorAll(".option").forEach(x=>x.disabled=true);const ok=i===q[2];if(ok){currentScore++;state.points+=10}document.getElementById("fb").innerHTML=`<div class="feedback ${ok?"correct":"wrong"}">${ok?"✓ "+t("Correct!","ትክክል!"): "✗ "+t("Not quite. Try the next one.","ትክክል አይደለም። ቀጣዩን ሞክር።")} ${ok?"":"<br>"+t("Correct answer: ","ትክክለኛው መልስ፦ ")+q[1][q[2]]}</div><div class="actions"><button class="btn" onclick="nextQuestion()">${currentQ===currentTopic.questions.length-1?t("Finish","ጨርስ"):t("Next","ቀጣይ")}</button></div>`;save()}
function nextQuestion(){if(currentQ<currentTopic.questions.length-1){currentQ++;practiceQuestion()}else{state.completed[currentTopic.id]=true;state.points+=currentScore*5;save();showResult()}}
function showResult(){const n=currentTopic.questions.length;const pct=Math.round(currentScore/n*100);document.getElementById("main").innerHTML=`<div class="lesson"><div class="card center"><h2>🎉 ${t("Practice complete!","ልምምድ ተጠናቋል!")}</h2><div class="stat">${pct}%</div><p>${currentScore} / ${n} ${t("correct","ትክክል")}</p><p>${pct>=80?t("Excellent work!","በጣም ጥሩ ስራ!"):t("Keep practicing. You are improving!","ልምምድህን ቀጥል። እየተሻሻልክ ነው!")}</p><button class="btn" onclick="courses()">${t("Back to Courses","ወደ ትምህርቶች")}</button></div></div>`}
function practice(){courses()}
function quiz(){quizQuestions=[];DATA.units.forEach(u=>u.topics.forEach(x=>x.questions.forEach(q=>quizQuestions.push({...q,topic:x.title}))));quizQuestions=quizQuestions.sort(()=>Math.random()-.5).slice(0,10);currentQ=0;currentScore=0;quizQuestion()}
function quizQuestion(){const q=quizQuestions[currentQ];document.getElementById("main").innerHTML=`<div class="lesson"><div class="card"><div class="muted">${t("Mixed Mathematics Quiz","የተለያዩ የሂሳብ ፈተና")} · ${currentQ+1}/10</div><div class="question">${q[0]}</div>${q[1].map((o,i)=>`<button class="option" onclick="quizAnswer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}<div id="fb"></div></div></div>`}
function quizAnswer(i){const q=quizQuestions[currentQ];document.querySelectorAll(".option").forEach(x=>x.disabled=true);const ok=i===q[2];if(ok){currentScore++;state.points+=15}document.getElementById("fb").innerHTML=`<div class="feedback ${ok?"correct":"wrong"}">${ok?"✓ Correct!":"✗ Keep learning."}</div><div class="actions"><button class="btn" onclick="nextQuiz()">${currentQ===9?"Finish":"Next"}</button></div>`;save()}
function nextQuiz(){if(currentQ<9){currentQ++;quizQuestion()}else{state.scores.push({date:new Date().toISOString(),score:currentScore});save();document.getElementById("main").innerHTML=`<div class="card center"><h2>📝 Quiz Result</h2><div class="stat">${currentScore}/10</div><p>${currentScore>=8?"Excellent!":currentScore>=5?"Good effort!":"Practice more and try again!"}</p><button class="btn" onclick="progress()">View Progress</button></div>`}}
function badges(){const b=[];if(state.points>=50)b.push("⭐ Practice Star");if(Object.values(state.completed).filter(Boolean).length>=3)b.push("🏆 Learning Explorer");if(state.points>=150)b.push("🥇 Mathematics Champion");return b}
function progress(){const done=Object.values(state.completed).filter(Boolean).length;const total=DATA.units.reduce((a,u)=>a+u.topics.length,0);document.getElementById("main").innerHTML=`<h2>📈 ${t("My Progress","እድገቴ")}</h2><div class="grid"><div class="card"><div class="muted">${t("Overall completion","አጠቃላይ እድገት")}</div><div class="stat">${Math.round(done/total*100)}%</div><div class="progress"><div style="width:${done/total*100}%"></div></div></div><div class="card"><div class="muted">${t("Points","ነጥቦች")}</div><div class="stat">${state.points}</div></div></div><div class="card" style="margin-top:18px"><h3>🏆 ${t("Badges","ሽልማቶች")}</h3>${badges().length?badges().map(x=>`<span class="badge">${x}</span>`).join(""):"<span class='muted'>Complete lessons to earn badges.</span>"}</div><div class="card" style="margin-top:18px"><h3>${t("Quiz history","የፈተና ታሪክ")}</h3>${state.scores.length?`<table class="table"><tr><th>Date</th><th>Score</th></tr>${state.scores.slice(-10).reverse().map(s=>`<tr><td>${new Date(s.date).toLocaleDateString()}</td><td>${s.score}/10</td></tr>`).join("")}</table>`:"No quizzes taken yet."}</div>`}
function teacher(){document.getElementById("main").innerHTML=`<h2>👨‍🏫 ${t("Teacher Dashboard","የመምህር መቆጣጠሪያ")}</h2><div class="grid"><div class="card"><h3>Class Overview</h3><div class="stat">${Object.values(state.completed).filter(Boolean).length}</div><p>Lessons completed by this demo student</p></div><div class="card"><h3>Practice Points</h3><div class="stat">${state.points}</div><p>Use the progress page for detailed student activity.</p></div></div><div class="card" style="margin-top:18px"><h3>Topics</h3><table class="table"><tr><th>Unit</th><th>Topics</th><th>Completed</th></tr>${DATA.units.map(u=>`<tr><td>${u.icon} ${u.title}</td><td>${u.topics.length}</td><td>${u.topics.filter(x=>state.completed[x.id]).length}</td></tr>`).join("")}</table></div><p class="small muted">This prototype uses local demo data. A production teacher dashboard should use authenticated server-side data.</p>`}
if("serviceWorker"in navigator)navigator.serviceWorker.register("service-worker.js").catch(()=>{});
app();